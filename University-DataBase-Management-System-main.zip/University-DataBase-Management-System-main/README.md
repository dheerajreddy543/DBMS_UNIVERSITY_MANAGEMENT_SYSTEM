# University-DataBase-Management-System
University database management system is used for a university to manage their database using the optimization techniques. The creation is in MY SQL
